﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weave.TCPClient
{
    public enum DataType { json, bytes };

    class EnumDataType
    {

    }
}
