﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iot10ClientClass
{
    public class Class1
    {
    }
}
