﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Weave.Base
{
    public class WevaeSocketSession
    {
        public string[] Parameter
        {
            get; set;
        }
    }
}
